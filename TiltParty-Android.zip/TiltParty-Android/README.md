# Tilt Party — Android

Heads-up guessing party game. The game itself is `app/src/main/assets/index.html`;
the Android app wraps it in a full-screen WebView, locks landscape during a round,
keeps the screen on, and reads the phone's motion sensor for tilt controls.

## Build the APK (Android Studio)
1. Install Android Studio (Ladybug or newer) and open this folder (File > Open).
2. Let Gradle sync. If it asks to create the Gradle wrapper, accept.
3. Plug in your phone (USB debugging on) and press Run, or
   Build > Build App Bundle(s)/APK(s) > Build APK(s). The APK lands in
   app/build/outputs/apk/debug/.

## Publish on Google Play
- Build > Generate Signed App Bundle, create an upload key, upload the .aab
  in Play Console. Change `applicationId` in app/build.gradle.kts to your own
  package name first.

## Edit decks
Open assets/index.html and edit the `DECKS` list near the top of the script.
Each deck: id, name, ico (emoji), c (tile colour), w (list of cards).

## Controls
- Tilt screen toward the floor = Correct, toward the ceiling = Pass
- Tap right half = Correct, left half = Pass
- Back button ends a round early
